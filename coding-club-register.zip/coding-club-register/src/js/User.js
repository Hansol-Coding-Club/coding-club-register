import {Req} from "./req";

export let User = new Req({
    studentNumber: null,
    name: null,
    phoneNumber: null,
    language: null,
    libraryAndFramework: null,
    mal: null,
    portfolio: null,
})