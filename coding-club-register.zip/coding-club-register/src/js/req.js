export class Req {
    constructor({studentNumber, name, phoneNumber, language, libraryAndFramework, mal, portfolio}) {
        this.studentNumber = studentNumber;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.languague = language;
        this.libraryAndFramework = libraryAndFramework;
        this.mal = mal;
        this.portfolio = portfolio;
    }
}