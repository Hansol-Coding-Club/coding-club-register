export const START_PAGE = "/";
export const FIRST_REGISTER_PAGE = "/first-register-page";
export const SECOND_REGISTER_PAGE = "/second-register-page";
export const RESULT_PAGE = "/result-page";