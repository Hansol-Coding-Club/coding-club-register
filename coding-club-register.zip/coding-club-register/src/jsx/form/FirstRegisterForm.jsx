import React, { useState } from 'react';
import '../../css/FirstRegisterForm.css'
import {LANGUAGE_DESCRIPTION} from "../../js/texts";
import NextButton from "../widget/NextButton";
import {InputField} from "../widget/InputField";
import {SECOND_REGISTER_PAGE} from "../../js/RouteLink";
import {User} from "../../js/User.js"

const NUM_INPUT_WIDTH = "40vw"
const NUM_INPUT_HEIGHT = "30pt"

const PHONE_NUM_INPUT_WIDTH = "84vw"
const PHONE_NUM_INPUT_HEIGHT = "30pt"


const FirstRegisterForm = () => {
    const [studentNumber, setStudentNumber] = useState("");
    const [name, setName] = useState("");
    const [phoneNumber, setPhoneNumber] = useState("");
    const [language, setLanguage] = useState("");
    const [libraryAndFramework, setLibraryAndFramework] = useState("");

    const handleNextClick = () => {
        if (studentNumber === "" || name === "" || phoneNumber === "" || language === "") {
            alert("모든 필수 필드를 채워주세요.");
            return false;
        } else {
            User.studentNumber = studentNumber;
            User.name = name;
            User.phoneNumber = phoneNumber;
            User.languague = language;
            User.libraryAndFramework = libraryAndFramework;
            return true;
        }
    };

    return (
        <div className="container">
            <div className="header">Codingclub 동아리 부원모집</div>
            <div className="form">
                <div style={{ustifyContent: "space-around", display: "flex", marginBottom: "10pt"}}>
                    <div style={{marginRight: "4vw"}}>
                        <InputField
                            label="학번" placeholder="예) 20904"
                            redStar={true}
                            width={NUM_INPUT_WIDTH}
                            height={NUM_INPUT_HEIGHT}
                            value={studentNumber}
                            onChange={e => setStudentNumber(e.target.value)}
                        />
                    </div>
                    <InputField
                        label="이름"
                        placeholder="이름을 입력해주세요."
                        redStar={true}
                        width={NUM_INPUT_WIDTH}
                        height={NUM_INPUT_HEIGHT}
                        value={name}
                        onChange={e => setName(e.target.value)}
                    />
                </div>

                <div style={{ustifyContent: "space-around",display: "flex", marginBottom: "10pt"}}>
                    <InputField
                        label="전화번호"
                        placeholder="예)010-XXXX-XXXX"
                        redStar={true}
                        width={PHONE_NUM_INPUT_WIDTH}
                        height={PHONE_NUM_INPUT_HEIGHT}
                        value={phoneNumber}
                        onChange={e => setPhoneNumber(e.target.value)}
                    />
                </div>

                <div style={{ustifyContent: "space-around",display: "flex", marginBottom: "10pt"}}>
                    <InputField
                        label="다룰 수 있는 개발 언어"
                        placeholder="없는경우 '없다' 혹은 'X'를 기입해주세요."
                        redStar={true}
                        width={PHONE_NUM_INPUT_WIDTH}
                        height={PHONE_NUM_INPUT_HEIGHT}
                        value={language}
                        onChange={e => setLanguage(e.target.value)}
                    />
                </div>

                <div style={{dustifyContent: "space-around",isplay: "flex",marginBottom: "10pt"}}>
                    <p style={{fontSize: '8pt', color: "#c0c0c0"}}>{LANGUAGE_DESCRIPTION}</p>
                </div>

                <div style={{ustifyContent: "space-around",display: "flex",marginBottom: "30pt"}}>
                    <InputField
                        label="사용해본 라이브러리/프레임워크/툴 (자유 기입)"
                        placeholder="예) 유니티, 스프링, 리액트 등.."
                        width={PHONE_NUM_INPUT_WIDTH}
                        height={PHONE_NUM_INPUT_HEIGHT}
                        value={libraryAndFramework}
                        onChange={e => setLibraryAndFramework(e.target.value)}
                    />
                </div>

                <div style={{display: "flex",justifyContent: "center"}}>
                    <NextButton
                        text="다음으로"
                        goto={SECOND_REGISTER_PAGE}
                        onClick={handleNextClick}
                    />
                </div>

            </div>
        </div>
    );
};


export default FirstRegisterForm;